﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using HarmonyLib;
using System.Collections;
using MonoBaseCheat;


namespace MonoBase
{
    internal class Handler
    {


        public static void DrawLogo()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("Make sure u have a logo");
            
        }
        public static void Log(string message, string CustomLog)
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("[");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write(CustomLog);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("] ");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write(message + "\n");
            Console.ForegroundColor = ConsoleColor.Gray;
        }

        public static void Log(string message)
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("[");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write(Loader.CheatName);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write("] ");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write(message + "\n");
            Console.ForegroundColor = ConsoleColor.Gray;
        }





        private static void CollectObjects<T>(List<T> list, Func<T, bool> filter = null) where T : MonoBehaviour
        {
            list.Clear();
            list.AddRange(filter == null ? UnityEngine.Object.FindObjectsOfType<T>() : UnityEngine.Object.FindObjectsOfType<T>().Where(filter));
        }

    }
}
