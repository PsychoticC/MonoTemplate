﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace MonoBase.Patches
{
    public class PatchableItem
    {
        public virtual void LoadPatch()
        {
            // Welcome to patchable items! Its easy to do. Check examples folders to get started.
        }

        public static void LoadAllPatches() // dont mind this
        {
            var patchableItems = Assembly.GetExecutingAssembly().GetTypes()
                .Where(t => t.IsSubclassOf(typeof(PatchableItem)) && !t.IsAbstract);

            foreach (var item in patchableItems)
            {
                var instance = (PatchableItem)Activator.CreateInstance(item);
                instance.LoadPatch();
            }
        }
    }
}
