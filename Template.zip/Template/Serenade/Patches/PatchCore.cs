﻿using HarmonyLib;
using MonoBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace HyperionML.Patches
{
    public class PatchCore
    {
        public static HarmonyLib.Harmony instance = new HarmonyLib.Harmony("Hyperion");

        public static void Detour(MethodBase Og, MethodInfo PostfixMethod)
        {
            Handler.Log($"{Og.Name} is being patched...");

            if (Og == null)
            {
                Handler.Log($"{Og.Name} is null");
            }

            if (PostfixMethod == null)
            {
                Handler.Log($"{PostfixMethod.Name} is null");
            }

            instance.Patch(Og, postfix: new HarmonyLib.HarmonyMethod(PostfixMethod));

            Handler.Log($"Patched {Og.Name}");
        }

        public static void PrefixDetour(MethodBase Og, MethodInfo PrefixMethod)
        {
            Handler.Log($"{Og.Name} is being patched...");

            if (Og == null)
            {
                Handler.Log($"{Og.Name} is null");
            }

            if (PrefixMethod == null)
            {
                Handler.Log($"{PrefixMethod.Name} is null");
            }

            instance.Patch(Og, prefix: new HarmonyLib.HarmonyMethod(PrefixMethod));

            Handler.Log($"Patched {Og.Name}");
        }
    }
}
