﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using HyperionML.Patches;
using MonoBase;
using MonoBase.Patches;

namespace Hyperion.Patches.Examples
{
    public class TestPatch : PatchableItem // Make sure ur class is a patchable item.
    {
        private static void PatchedMethod()
        {
            // This method is gonna be patched for use
            Handler.Log("Patched");
        }

        public override void LoadPatch()
        {
            // Call this method as an override to trigger the patch on runtime or whenever called.

            var original = typeof(TestPatchClass).GetMethod(nameof(TestPatchClass.BeforePatch));
            var PatchedMethodFound = typeof(TestPatch).GetMethod(nameof(PatchedMethod), BindingFlags.NonPublic | BindingFlags.Static); // Gets the patched method for use. Make sure you use bindingflags

            PatchCore.Detour(original, PatchedMethodFound); // Use PatchCore.Detour to pass ur vars and patch the method easily.
        }
    }
}
