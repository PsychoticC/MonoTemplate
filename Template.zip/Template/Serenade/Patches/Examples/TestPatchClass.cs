﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MonoBase;

namespace Hyperion.Patches.Examples
{
    public class TestPatchClass
    {
        public static void BeforePatch()
        {
            // This method is gonna be patched for use

            Handler.Log("Before patched");
        }
    }
}
