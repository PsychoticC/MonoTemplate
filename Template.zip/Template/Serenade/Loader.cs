﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Text;
using System;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;
using System.IO;
using System.Reflection;
using Object = UnityEngine.Object;
using System.Linq;
using HarmonyLib;
using UnityEngine.UI;

using System.Runtime.InteropServices;
using static UnityEngine.Rendering.VirtualTexturing.Debugging;
using System.Net;

using MonoBase.Patches;
using MonoBase;


namespace MonoBaseCheat
{


    internal class Loader
    {
        [DllImport("kernel32.dll")]
        private static extern int AllocConsole();

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetConsoleWindow();

        private static void ShowConsole()
        {
            SetForegroundWindow(GetConsoleWindow());
        }


        private static GameObject loader;
        static Assembly OnResolveAssembly(object _, ResolveEventArgs args) { Assembly assembly = Assembly.GetExecutingAssembly(); string resourceName = assembly.GetManifestResourceNames().First(name => name.EndsWith($"{new AssemblyName(args.Name).Name}.dll")); if (string.IsNullOrWhiteSpace(resourceName)) { Handler.Log($"Failed to resolve assembly: {args.Name}"); throw new FileNotFoundException(); } Stream stream = assembly.GetManifestResourceStream(resourceName); MemoryStream memoryStream = new MemoryStream(); stream.CopyTo(memoryStream); return Assembly.Load(memoryStream.ToArray()); }

        public static string CheatName = "Mono Base";
        public static string CheatVersion = "1.0.0";
        public static string CheatAuthor = "AUTHOR";

        /// <summary>
        /// The method to call in the Panel to start the process.
        /// </summary>
        public static void InjectionStart() 
        {
       
            try
            {
                string harmonyDllPath = AppDomain.CurrentDomain.BaseDirectory + "/0Harmony.dll";
                if (!File.Exists(harmonyDllPath))
                {
                    byte[] nut = Convert.FromBase64String(HR.harmonyDll);
                    File.WriteAllBytes(harmonyDllPath, nut);
                }
                else
                {
                }
            }
            catch (System.Exception e)
            {
                
            }
            AppDomain.CurrentDomain.AssemblyResolve += Loader.OnResolveAssembly;
            Create();

            PatchableItem.LoadAllPatches(); // Loads patches
            loader = new GameObject();
            loader.AddComponent<hax>();
            Object.DontDestroyOnLoad(loader);
            

            
            AppDomain.CurrentDomain.AssemblyResolve -= Loader.OnResolveAssembly;
            Handler.DrawLogo();
        }

        public static void Unload() => Object.Destroy(loader);



        public static void Create()
        {
            AllocConsole();
            Console.SetOut(new StreamWriter(Console.OpenStandardOutput())
            {
                AutoFlush = true
            });
            Console.SetIn(new StreamReader(Console.OpenStandardInput()));
            Console.Clear();
            Console.Title = "MONO BASE CHEAT"; // This is the console title
            ShowConsole();

            Console.CursorVisible = false;
            Console.OutputEncoding = Encoding.UTF8;
        }

    }


}
