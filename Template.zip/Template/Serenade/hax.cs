﻿
using HarmonyLib;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using TMPro;

using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Video;
using System.IO;
using System.Media;
using MonoBaseCheat;

namespace MonoBase
{
    internal class hax : MonoBehaviour
    {
        #region VARS

        private Rect menuRect = new Rect(10, 10, 400, 400);
         
        private int selectedTab = 0;
        private string[] tabNames = {"Tab One", "Tab Two", "Tab Three"};

        private bool TestToggle = false;
        



        #endregion VARS 

        public void DrawMenu(int windowID)
        {   

            GUILayout.BeginHorizontal(); 
            for (int i = 0; i < tabNames.Length; i++)
            {
                if (GUILayout.Toggle(selectedTab == i, tabNames[i], "Button", GUILayout.ExpandWidth(true)))
                {
                    selectedTab = i;
                }
            }
            GUILayout.EndHorizontal();

            switch (selectedTab)
            {
                case 0:
                    if (GUILayout.Button("Test"))
                    {
                        Handler.Log("Test");
                    }

                    GUILayout.Toggle(TestToggle, "TestToggle"); // creates toggle on menu
                    if (TestToggle)
                    {
                        // When its on
                    }
                    else
                    {
                        //If the toggle is off
                    }

                    break;

                
            }

            // Save and load config buttons
            GUILayout.BeginArea(new Rect(10, menuRect.height - 30, menuRect.width - 90, 40));
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Unload"))
            {
                Loader.Unload();
            }
            GUILayout.EndHorizontal();
            GUILayout.EndArea();

            GUI.DragWindow(); // Allow the user to drag the window around
        }







        private void Update()
        {
            //Here you can functions for OnUpdate
        }

        
        private void OnGUI()
        {
            GUI.backgroundColor = Color.black; // background color
            menuRect = GUI.Window(0, menuRect, DrawMenu, $"{Loader.CheatName} {Loader.CheatVersion}");

        }
    }
}